create
    definer = root@`%` procedure insert_user_and_roles(OUT userid bigint, IN userName varchar(50),
                                                       IN userPassword varchar(50), IN userEmail varchar(50),
                                                       IN userinfo text, IN headimg blob, OUT createTime datetime,
                                                       IN roleIds varchar(200))
BEGIN
SET createTime=now();
INSERT INTO sys_user(user_name , user_password , user_email , user_info ,head_img, create_time)
VALUES (userName , userPassword, userEmail , userinfo , headimg , createTime) ;

SELECT LAST_INSERT_ID() INTO userId ;
SET roleIds = CONCAT (',' , roleIds ,',' ) ;
INSERT INTO sys_user_role(user_id , role_id)
select userid , id from sys_role
where INSTR(roleIds , CONCAT(',', id,',') ) > 0 ;
END;


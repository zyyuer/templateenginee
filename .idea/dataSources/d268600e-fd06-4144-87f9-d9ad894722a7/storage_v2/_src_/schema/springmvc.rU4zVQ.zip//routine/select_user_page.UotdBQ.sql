create
    definer = root@`%` procedure select_user_page(IN userName varchar(50), IN _offset bigint, IN _limit bigint,
                                                  OUT total bigint)
BEGIN
select count(*) into total
from sys_user
where user_name like CONCAT('%',userName,'%');
select * from sys_user
where user_name like concat('%',userName,'%')
limit _offset,_limit;
end;


create
    definer = root@`%` procedure delete_user_by_id(IN userid bigint)
BEGIN
DELETE FROM sys_user_role where user_id = userid ;
DELETE FROM sys_user where id = userid ;
END;

